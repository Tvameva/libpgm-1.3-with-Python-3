__all__ = ['discrete', 'lg', 'lgandd', 'crazy']
